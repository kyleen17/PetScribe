import React, { useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Agenda } from 'react-native-calendars';

export default function CalendarTab() {
  const [items, setItems] = useState({
    '2025-05-20': [
      { name: 'Vet Appointment - Koda', type: 'Vet', time: '2:00 PM' },
      { name: 'Birthday - Chopper', type: 'Birthday' }
    ],
    '2025-05-21': [
      { name: 'Flea Medication - Koda', type: 'Medication', time: '8:00 AM' }
    ]
  });

  const renderItem = (item) => {
    return (
      <View style={[styles.item, { borderLeftColor: getColor(item.type) }]}>
        <Text>{item.name}</Text>
        {item.time && <Text style={styles.time}>🕒 {item.time}</Text>}
      </View>
    );
  };

  const getColor = (type) => {
    switch (type) {
      case 'Vet': return '#ff6961';
      case 'Birthday': return '#f49ac2';
      case 'Medication': return '#77dd77';
      default: return '#ccc';
    }
  };

  return (
    <View style={{ flex: 1 }}>
      <Agenda
        items={items}
        selected={'2025-05-20'}
        renderItem={renderItem}
        renderEmptyData={() => (
          <View style={styles.empty}>
            <Text>No events</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  item: {
    backgroundColor: 'white',
    padding: 15,
    marginRight: 10,
    marginTop: 17,
    borderRadius: 5,
    borderLeftWidth: 4
  },
  time: {
    fontSize: 12,
    color: '#888'
  },
  empty: {
    padding: 20,
    alignItems: 'center'
  }
});
