import { Slot } from 'expo-router';
import { useEffect } from 'react';

export default function AppLayout() {
  useEffect(() => {
    console.log('🔄 AppLayout rendered');
  }, []);

  return <Slot />;
}
